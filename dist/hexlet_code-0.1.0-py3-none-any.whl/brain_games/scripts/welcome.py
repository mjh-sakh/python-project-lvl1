#!/usr/bin/env python
"""Empty docstring."""

from brain_games import cli


def main():
    """Game run."""
    cli.welcome_user()


if __name__ == '__main__':
    main()
