#!/usr/bin/env python
"""Empty docstring."""

from brain_games import cli


def main():
    """Game run."""
    cli.just_say_hello()


if __name__ == '__main__':
    main()
